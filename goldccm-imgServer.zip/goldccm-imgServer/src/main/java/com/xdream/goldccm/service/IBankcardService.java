package com.xdream.goldccm.service;

public interface IBankcardService {
	
	/**
	 * 银行卡
	 * @param filepath
	 * @return
	 */
	public String getBankCardData(String filepath) throws Exception;

}
