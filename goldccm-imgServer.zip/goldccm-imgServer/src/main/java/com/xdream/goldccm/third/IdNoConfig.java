package com.xdream.goldccm.third;

public class IdNoConfig {

	public static String api_key;
	public static String api_secret;
	public static String url;
}
