package com.xdream.goldccm.service;

public interface IBankCardDiscernService {
	/**LL
	 * 银行卡
	 * @param filepath
	 * @return
	 */
	public String getBankCardDiscern(String filepath) throws Exception;
}
