package com.xdream.goldccm.third;

public class BankConfig {
	public static String key;
	public static String secret;
	public static String url;
}
