package com.xdream.goldccm.third;

public class DB40Config {
	
	public static String DB40Dir;
}
