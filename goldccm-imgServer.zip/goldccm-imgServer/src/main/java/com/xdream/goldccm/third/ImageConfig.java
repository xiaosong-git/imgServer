package com.xdream.goldccm.third;

public class ImageConfig {
	
	public static String imageSaveDir;
}
