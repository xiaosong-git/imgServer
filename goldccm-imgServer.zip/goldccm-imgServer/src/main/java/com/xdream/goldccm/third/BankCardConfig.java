package com.xdream.goldccm.third;

public class BankCardConfig {

	public static String key;
	public static String secret;
	public static String url;
}
