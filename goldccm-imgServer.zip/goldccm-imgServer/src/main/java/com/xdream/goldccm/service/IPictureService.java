package com.xdream.goldccm.service;

public interface IPictureService {
	
	/**
	 * 身份证
	 * @param filepath
	 * @return
	 */
	public String getCardData(String filepath) throws Exception;

}
