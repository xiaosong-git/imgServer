package com.xdream.uaas.server.tools;

import java.util.List;

public class ResponseBank {

	
	private  String cardNumber;//卡号

    private  String bankCardType;//银行卡类型
    
    private  String bankCradName;//银行卡名称
    
    private  String bankName;//银行名称
    
    private  String bankNumber;//银行编号

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getBankCardType() {
		return bankCardType;
	}

	public void setBankCardType(String bankCardType) {
		this.bankCardType = bankCardType;
	}

	public String getBankCradName() {
		return bankCradName;
	}

	public void setBankCradName(String bankCradName) {
		this.bankCradName = bankCradName;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankNumber() {
		return bankNumber;
	}

	public void setBankNumber(String bankNumber) {
		this.bankNumber = bankNumber;
	}
    
    
	
	
}
